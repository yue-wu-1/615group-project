matrix_thin <-
function(matrix, R2 = 0.99999, verbose = FALSE) {
  n <- dim(matrix)[1]
  rm_index <- vector()
  for (i in 1:(n - 1)) {
    lds <- matrix[i, (i+1):n]^2
    redundant <- which(lds > R2) + i
    rm_index <- c(rm_index, redundant)
    rm_index <- unique(rm_index)
  }

  if (length(rm_index) >= 1) {
    if (verbose) {message(paste("Removed entries", rm_index))}
  } else {
    if (verbose){message("No variants removed by thinning!")}
  }

  matrix_thinned <- matrix[-rm_index, -rm_index]
  if (length(matrix_thinned) == 1) {
    warning("All but one variant removed - the score statistic needs at least two variants.")
  }

  return(matrix_thinned)
}
