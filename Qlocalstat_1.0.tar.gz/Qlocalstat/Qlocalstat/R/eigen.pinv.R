eigen.pinv <-
function(Omega) {
  #an eigenvalue based pseudoinverse
  eigenO <- eigen(Omega)
  svdO <- svd(Omega)

  if (any(eigenO$values < 0)) {
    neg_eigen <- eigenO$values[eigenO$values < 0]
    dinv <- vector()
    for (j in 1:length(svdO$d)) {
      if (any(abs(svdO$d[j] + neg_eigen) < 1e-15)) {
        dinv[j] <- 0 #remove the singular value because it equals a negative eigenvalue
      } else {
        dinv[j] <- 1/svdO$d[j] #keep the singular value, and invert it
      }
    }
  } else { #the matrix is positive definite, no worries.
    dinv <- 1/svdO$d
  }
  return(svdO$v %*% diag(dinv) %*% t(svdO$u))
}
